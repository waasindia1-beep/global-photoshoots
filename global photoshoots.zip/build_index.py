# Python script to generate complete index.html for Global Photoshoots
import os

HTML_CONTENT = """<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Global Photoshoots | Sudhir Kumar Solanki — Commercial AI Photography & Video Studio</title>
  <meta name="description" content="Next-Gen AI Photography & Video Studio by Sudhir Kumar Solanki. Hyper-photorealistic editorial imagery, e-commerce campaigns, and cinematic AI video at 90% lower cost." />
  
  <!-- Google Fonts: Syne & Outfit & JetBrains Mono -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Outfit:wght@300;400;500;600;700;800;900&family=Syne:wght@600;700;800&display=swap" rel="stylesheet" />

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          fontFamily: {
            heading: ['Syne', 'sans-serif'],
            sans: ['Outfit', 'sans-serif'],
            mono: ['JetBrains Mono', 'monospace'],
          },
          colors: {
            brand: {
              cyan: '#38bdf8',
              indigo: '#6366f1',
              violet: '#8b5cf6',
              dark: '#07090e',
              card: '#0f131f'
            }
          }
        }
      }
    };
  </script>

  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="styles.css" />
</head>
<body class="bg-[#07090e] text-slate-100 font-sans selection:bg-cyan-500 selection:text-black antialiased overflow-x-hidden">

  <!-- Ambient Glowing Orbs Background -->
  <div class="fixed inset-0 pointer-events-none z-0 overflow-hidden">
    <div class="absolute -top-40 -left-40 w-96 h-96 bg-cyan-600/15 rounded-full blur-[120px] glow-orb"></div>
    <div class="absolute top-1/3 -right-40 w-[30rem] h-[30rem] bg-indigo-600/15 rounded-full blur-[140px] glow-orb" style="animation-delay: 3s;"></div>
    <div class="absolute -bottom-40 left-1/4 w-[32rem] h-[32rem] bg-violet-600/15 rounded-full blur-[140px] glow-orb" style="animation-delay: 5s;"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
  </div>

  <!-- Announcement / Instagram Banner -->
  <div class="relative z-50 bg-gradient-to-r from-cyan-950/60 via-indigo-950/60 to-purple-950/60 border-b border-white/5 backdrop-blur-md text-xs py-2 px-4 text-center">
    <div class="max-w-7xl mx-auto flex items-center justify-center gap-2 flex-wrap text-slate-300">
      <span class="inline-flex items-center gap-1 text-cyan-400 font-semibold">
        <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
        <span>Official AI Production Studio</span>
      </span>
      <span class="hidden sm:inline text-white/30">•</span>
      <span>Follow &amp; DM Sudhir on Instagram:</span>
      <a 
        href="https://www.instagram.com/global.photoshoots/#" 
        target="_blank" 
        rel="noopener noreferrer" 
        class="inline-flex items-center gap-1 font-bold text-white hover:text-cyan-300 transition-colors underline decoration-cyan-400/40 hover:decoration-cyan-300"
      >
        <i data-lucide="instagram" class="w-3.5 h-3.5 text-pink-400"></i>
        <span>@global.photoshoots</span>
      </a>
      <span class="hidden sm:inline text-white/30">•</span>
      <span class="text-emerald-400 font-medium">⚡ Accepting Q3/Q4 Brand Bookings</span>
    </div>
  </div>

  <!-- Main Navigation Header -->
  <header class="sticky top-0 z-40 bg-[#07090e]/85 backdrop-blur-xl border-b border-white/10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
      
      <!-- Brand Logo -->
      <a href="#" class="flex items-center gap-3 group">
        <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 p-[2px] shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-500/40 transition-all duration-300">
          <div class="w-full h-full bg-[#0a0d16] rounded-[14px] flex items-center justify-center">
            <i data-lucide="aperture" class="w-6 h-6 text-cyan-400 group-hover:rotate-45 transition-transform duration-500"></i>
          </div>
        </div>
        <div>
          <span class="font-heading font-extrabold text-lg sm:text-xl tracking-tight text-white flex items-center gap-1">
            GLOBAL<span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">PHOTOSHOOTS</span>
          </span>
          <p class="text-[11px] font-mono text-slate-400 tracking-wider -mt-1">by Sudhir Kumar Solanki</p>
        </div>
      </a>

      <!-- Desktop Nav Links -->
      <nav class="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
        <a href="#showcase" class="hover:text-cyan-400 transition-colors">Precision AI</a>
        <a href="#why-ai" class="hover:text-cyan-400 transition-colors">Why AI</a>
        <a href="#calculator" class="hover:text-cyan-400 transition-colors">ROI Calculator</a>
        <a href="#portfolio" class="hover:text-cyan-400 transition-colors">8K Portfolio</a>
        <a href="#packages" class="hover:text-cyan-400 transition-colors">Pricing</a>
        <a href="#store" class="hover:text-cyan-400 transition-colors">Digital Store</a>
        <a href="#workflow" class="hover:text-cyan-400 transition-colors">Workflow</a>
        <a href="#faq" class="hover:text-cyan-400 transition-colors">FAQs</a>
      </nav>

      <!-- Header Action Group (Currency + WhatsApp + CTA) -->
      <div class="hidden sm:flex items-center gap-3">
        
        <!-- Multi-Currency Selector Dropdown -->
        <div class="relative flex items-center bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 hover:border-cyan-500/40 transition-colors">
          <i data-lucide="globe" class="w-3.5 h-3.5 text-cyan-400 mr-1.5"></i>
          <select 
            id="currencySelector" 
            class="bg-transparent text-xs font-mono text-white focus:outline-none cursor-pointer pr-1"
            title="Choose Currency"
          >
            <option value="USD" class="bg-[#0f131f] text-white">USD ($)</option>
            <option value="INR" class="bg-[#0f131f] text-white">INR (₹)</option>
            <option value="EUR" class="bg-[#0f131f] text-white">EUR (€)</option>
            <option value="GBP" class="bg-[#0f131f] text-white">GBP (£)</option>
          </select>
        </div>

        <!-- WhatsApp Quick Connect -->
        <a 
          href="https://wa.me/917557575514?text=Hi%20Sudhir!%20I%20am%20interested%20in%20an%20AI%20Photoshoot%20for%20my%20brand." 
          target="_blank" 
          rel="noopener noreferrer" 
          class="p-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl transition-colors"
          title="Direct WhatsApp with Sudhir"
        >
          <i data-lucide="message-circle" class="w-4 h-4"></i>
        </a>

        <!-- Instagram CTA -->
        <a 
          href="https://www.instagram.com/global.photoshoots/#" 
          target="_blank" 
          rel="noopener noreferrer" 
          class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 text-white hover:brightness-110 transition-all shadow-md shadow-pink-600/20"
        >
          <i data-lucide="instagram" class="w-3.5 h-3.5"></i>
          <span>Instagram</span>
        </a>

        <!-- Book Shoot CTA -->
        <a 
          href="#estimator-section" 
          class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 transition-all shadow-lg shadow-cyan-400/20"
        >
          <span>Book Shoot</span>
          <i data-lucide="arrow-up-right" class="w-3.5 h-3.5"></i>
        </a>
      </div>

      <!-- Mobile Menu Button -->
      <button id="mobileMenuBtn" class="lg:hidden p-2 text-slate-300 hover:text-white rounded-lg focus:outline-none">
        <i data-lucide="menu" class="w-6 h-6"></i>
      </button>

    </div>

    <!-- Mobile Dropdown Menu -->
    <div id="mobileMenu" class="hidden lg:hidden border-t border-white/10 bg-[#0a0d16] px-4 py-6 space-y-4">
      <div class="grid grid-cols-2 gap-3 text-sm font-medium">
        <a href="#showcase" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">Precision AI</a>
        <a href="#why-ai" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">Why AI</a>
        <a href="#calculator" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">ROI Calculator</a>
        <a href="#portfolio" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">8K Portfolio</a>
        <a href="#packages" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">Pricing Packages</a>
        <a href="#store" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">Digital Store</a>
        <a href="#workflow" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">Workflow</a>
        <a href="#faq" class="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/10 hover:text-cyan-400">FAQs</a>
      </div>
      <div class="pt-4 border-t border-white/10 flex flex-col gap-3">
        <a 
          href="https://wa.me/917557575514" 
          target="_blank" 
          rel="noopener noreferrer" 
          class="w-full flex items-center justify-center gap-2 py-3 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-xl font-semibold"
        >
          <i data-lucide="message-circle" class="w-4 h-4"></i>
          <span>Chat on WhatsApp (+91 7557575514)</span>
        </a>
        <a 
          href="https://www.instagram.com/global.photoshoots/#" 
          target="_blank" 
          rel="noopener noreferrer" 
          class="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-xl font-semibold"
        >
          <i data-lucide="instagram" class="w-4 h-4"></i>
          <span>Follow @global.photoshoots</span>
        </a>
      </div>
    </div>
  </header>

  <!-- HERO SECTION -->
  <section class="relative pt-16 pb-24 md:pt-24 md:pb-32 overflow-hidden z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <!-- Top Badge -->
      <div class="flex justify-center mb-6">
        <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs sm:text-sm font-medium backdrop-blur-md">
          <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
          <span>Hyper-Photorealistic AI Visual Productions for Global Brands &amp; Creators</span>
        </div>
      </div>

      <!-- Main Headline -->
      <div class="text-center max-w-5xl mx-auto">
        <h1 class="font-heading font-extrabold text-4xl sm:text-6xl lg:text-7xl tracking-tight text-white leading-[1.1]">
          Commercial AI Photoshoots &amp; Video Campaigns at
          <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400"> ~90% Lower Cost.</span>
        </h1>
      </div>

      <!-- Founder's Signature Quote Box -->
      <div class="max-w-3xl mx-auto mt-8 p-6 rounded-2xl bg-gradient-to-b from-white/[0.07] to-white/[0.02] border border-white/10 backdrop-blur-md shadow-2xl relative">
        <div class="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-mono font-extrabold uppercase tracking-widest">
          The Art of Generative Physics
        </div>
        <p class="italic text-slate-300 text-sm sm:text-base leading-relaxed">
          &ldquo;To the uninitiated, AI photography might seem like &lsquo;pressing a button.&rsquo; To the expert, it is a sophisticated symphony of technical precision, lighting mastery, and generative physics.&rdquo;
        </p>
        <div class="mt-3 flex items-center justify-between text-xs font-mono text-cyan-400 pt-3 border-t border-white/5">
          <span class="font-semibold text-white">&mdash; Sudhir Kumar Solanki</span>
          <a href="https://www.instagram.com/global.photoshoots/#" target="_blank" rel="noopener noreferrer" class="hover:underline flex items-center gap-1 text-slate-400 hover:text-cyan-300">
            <i data-lucide="instagram" class="w-3 h-3"></i>
            <span>@global.photoshoots</span>
          </a>
        </div>
      </div>

      <!-- CTAs & Action Row -->
      <div class="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
        <a 
          href="#estimator-section" 
          class="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-xl text-base font-bold bg-gradient-to-r from-cyan-400 to-indigo-500 hover:from-cyan-300 hover:to-indigo-400 text-slate-950 transition-all transform hover:-translate-y-0.5 shadow-xl shadow-cyan-500/25"
        >
          <i data-lucide="camera" class="w-5 h-5"></i>
          <span>Commission a Photoshoot</span>
        </a>

        <a 
          href="https://wa.me/917557575514?text=Hi%20Sudhir!%20I%20saw%20Global%20Photoshoots%20and%20want%20to%20discuss%20a%20commercial%20AI%20shoot." 
          target="_blank" 
          rel="noopener noreferrer" 
          class="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl text-base font-semibold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 transition-all"
        >
          <i data-lucide="message-circle" class="w-5 h-5 text-emerald-400"></i>
          <span>WhatsApp Sudhir (+91 7557575514)</span>
        </a>

        <a 
          href="#calculator" 
          class="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl text-base font-medium bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition-all"
        >
          <i data-lucide="calculator" class="w-4 h-4 text-cyan-400"></i>
          <span>Calculate Savings</span>
        </a>
      </div>

      <!-- Key Trust Metrics -->
      <div class="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
        <div class="p-4 rounded-2xl bg-white/[0.03] border border-white/5 text-center">
          <div class="font-heading font-extrabold text-2xl sm:text-3xl text-cyan-400">8K Ultra-Res</div>
          <div class="text-xs text-slate-400 mt-1">Print &amp; Billboard Ready</div>
        </div>
        <div class="p-4 rounded-2xl bg-white/[0.03] border border-white/5 text-center">
          <div class="font-heading font-extrabold text-2xl sm:text-3xl text-indigo-400">24&ndash;48 Hours</div>
          <div class="text-xs text-slate-400 mt-1">Lightning Fast Delivery</div>
        </div>
        <div class="p-4 rounded-2xl bg-white/[0.03] border border-white/5 text-center">
          <div class="font-heading font-extrabold text-2xl sm:text-3xl text-emerald-400">~90% Savings</div>
          <div class="text-xs text-slate-400 mt-1">Zero Studio / Flight Costs</div>
        </div>
        <div class="p-4 rounded-2xl bg-white/[0.03] border border-white/5 text-center">
          <div class="font-heading font-extrabold text-2xl sm:text-3xl text-purple-400">100% IP Ownership</div>
          <div class="text-xs text-slate-400 mt-1">Full Commercial Copyright</div>
        </div>
      </div>

    </div>
  </section>

  <!-- INTERACTIVE BEFORE / AFTER COMPARISON SLIDER -->
  <section id="showcase" class="py-20 bg-[#0a0c14] border-y border-white/5 relative z-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="text-center max-w-3xl mx-auto mb-12">
        <span class="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">Generative Physics in Action</span>
        <h2 class="font-heading font-bold text-3xl sm:text-4xl text-white mt-2 mb-4">
          From Concept Prompt Geometry to Ultra-Luxury Editorial
        </h2>
        <p class="text-slate-400 text-sm sm:text-base">
          Drag the slider horizontally to see how Sudhir Kumar Solanki translates lighting schematics and structural prompts into hyper-photorealistic commercial imagery.
        </p>
      </div>

      <!-- Split Slider Card -->
      <div class="relative max-w-4xl mx-auto rounded-3xl overflow-hidden border border-white/15 shadow-2xl shadow-cyan-950/40 select-none cursor-ew-resize" id="beforeAfterSlider">
        
        <!-- After Image (Full Background) -->
        <div class="relative aspect-[16/10] sm:aspect-[16/9] w-full bg-slate-900">
          <img 
            src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1600&auto=format&fit=crop" 
            alt="Ultra Realistic High-Fashion Editorial Render" 
            class="w-full h-full object-cover object-center pointer-events-none"
          />
          <div class="absolute top-4 right-4 bg-black/70 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-semibold text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>Finished 8K AI Editorial</span>
          </div>
        </div>

        <!-- Before Image (Overlay clipped with width) -->
        <div class="absolute inset-0 overflow-hidden w-1/2 pointer-events-none" id="sliderBeforeContainer">
          <div class="absolute inset-0 aspect-[16/10] sm:aspect-[16/9] w-[896px] sm:w-[896px] max-w-none">
            <img 
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1600&auto=format&fit=crop" 
              alt="Raw Model Wireframe & Lighting Schematic" 
              class="w-full h-full object-cover object-center filter grayscale contrast-125 brightness-75"
            />
            <div class="absolute inset-0 bg-cyan-950/40 mix-blend-overlay"></div>
            <div class="absolute inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] opacity-30"></div>
          </div>
          <div class="absolute top-4 left-4 bg-black/70 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-semibold text-cyan-300 border border-cyan-500/30 flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
            <span>Raw Prompt &amp; Lighting Schematic</span>
          </div>
        </div>

        <!-- Draggable Handle Divider -->
        <div class="absolute top-0 bottom-0 left-1/2 -ml-0.5 w-1 bg-white cursor-ew-resize flex items-center justify-center shadow-[0_0_15px_rgba(56,189,248,0.8)]" id="sliderHandle">
          <div class="w-9 h-9 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shadow-lg font-bold">
            <i data-lucide="chevrons-left-right" class="w-5 h-5"></i>
          </div>
        </div>

      </div>

      <!-- Comparison Specs Legend -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl mx-auto mt-6 text-xs text-slate-400 font-mono">
        <div class="flex items-center gap-2 bg-white/[0.03] p-3 rounded-xl border border-white/5">
          <i data-lucide="sun" class="w-4 h-4 text-amber-400"></i>
          <span>Lighting: Raytraced Fresnel &amp; 5600K Key</span>
        </div>
        <div class="flex items-center gap-2 bg-white/[0.03] p-3 rounded-xl border border-white/5">
          <i data-lucide="camera" class="w-4 h-4 text-cyan-400"></i>
          <span>Optics: Hasselblad 85mm f/1.4 Simulation</span>
        </div>
        <div class="flex items-center gap-2 bg-white/[0.03] p-3 rounded-xl border border-white/5">
          <i data-lucide="shield-check" class="w-4 h-4 text-emerald-400"></i>
          <span>Resolution: Native 8192 × 5464 Px Output</span>
        </div>
      </div>

    </div>
  </section>

  <!-- WHY AI BATTLE CARD (AI VS TRADITIONAL) -->
  <section id="why-ai" class="py-24 relative z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="text-center max-w-3xl mx-auto mb-16">
        <span class="text-xs font-mono font-semibold uppercase tracking-widest text-indigo-400">The Economics of Modern Media</span>
        <h2 class="font-heading font-bold text-3xl sm:text-5xl text-white mt-2 mb-4">
          Why Leading Brands Are Shifting to AI Shoots
        </h2>
        <p class="text-slate-400 text-sm sm:text-base">
          Physical photoshoots are slow, fragile to bad weather, and cost thousands in studio hire, model casting, and equipment rentals. Global Photoshoots delivers superior luxury visuals in hours.
        </p>
      </div>

      <!-- Side-by-Side Comparison Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
        
        <!-- Traditional Physical Shoots -->
        <div class="p-8 rounded-3xl bg-rose-950/10 border border-rose-500/20 relative">
          <div class="flex items-center justify-between mb-6">
            <span class="text-xs font-mono text-rose-400 uppercase tracking-wider font-semibold">Traditional Production</span>
            <span class="px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold">Slow &amp; Expensive</span>
          </div>
          <h3 class="text-2xl font-bold text-white mb-6 font-heading">Physical Studio / Location Shoots</h3>
          
          <ul class="space-y-4 text-sm text-slate-300">
            <li class="flex items-start gap-3">
              <i data-lucide="x-circle" class="w-5 h-5 text-rose-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">Studio &amp; Location Fees:</strong> $2,500 – $7,000+ per single day.
              </div>
            </li>
            <li class="flex items-start gap-3">
              <i data-lucide="x-circle" class="w-5 h-5 text-rose-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">Models &amp; Hair/Makeup:</strong> $1,500 – $4,000+ with strict agency usage rights expiration.
              </div>
            </li>
            <li class="flex items-start gap-3">
              <i data-lucide="x-circle" class="w-5 h-5 text-rose-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">Turnaround Time:</strong> 3 to 5 weeks for shoot coordination, weather delays, and retouching.
              </div>
            </li>
            <li class="flex items-start gap-3">
              <i data-lucide="x-circle" class="w-5 h-5 text-rose-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">Revision Costs:</strong> Reshooting requires renting the entire crew and studio all over again.
              </div>
            </li>
          </ul>
        </div>

        <!-- Global Photoshoots AI Studio -->
        <div class="p-8 rounded-3xl bg-gradient-to-b from-cyan-950/30 to-indigo-950/20 border border-cyan-500/30 relative shadow-2xl shadow-cyan-950/50">
          <div class="absolute -top-3 right-6 px-3 py-0.5 rounded-full bg-cyan-400 text-slate-950 text-[10px] font-mono font-extrabold uppercase tracking-widest">
            Recommended Choice
          </div>
          <div class="flex items-center justify-between mb-6">
            <span class="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">Global Photoshoots</span>
            <span class="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">90% Cheaper &bull; 48H</span>
          </div>
          <h3 class="text-2xl font-bold text-white mb-6 font-heading">Generative AI Studio Production</h3>
          
          <ul class="space-y-4 text-sm text-slate-300">
            <li class="flex items-start gap-3">
              <i data-lucide="check-circle" class="w-5 h-5 text-cyan-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">Infinite Exotic Locations:</strong> Zero travel, zero permits. Paris, Tokyo, Sahara, or Martian studio in seconds.
              </div>
            </li>
            <li class="flex items-start gap-3">
              <i data-lucide="check-circle" class="w-5 h-5 text-cyan-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">Custom Virtual Models:</strong> Any ethnicity, aesthetic, age, or look tailored to your target demographic with zero recurring agency royalties.
              </div>
            </li>
            <li class="flex items-start gap-3">
              <i data-lucide="check-circle" class="w-5 h-5 text-cyan-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">24&ndash;48 Hour Turnaround:</strong> Campaign ready for Instagram, TikTok, Amazon, and print in days.
              </div>
            </li>
            <li class="flex items-start gap-3">
              <i data-lucide="check-circle" class="w-5 h-5 text-cyan-400 shrink-0 mt-0.5"></i>
              <div>
                <strong class="text-white">Full Commercial Copyright:</strong> 100% perpetual commercial IP transfer included.
              </div>
            </li>
          </ul>
        </div>

      </div>

    </div>
  </section>

  <!-- INTERACTIVE ROI / SAVINGS CALCULATOR -->
  <section id="calculator" class="py-20 bg-[#0a0d16] border-y border-white/5 relative z-10">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="text-center max-w-3xl mx-auto mb-12">
        <span class="text-xs font-mono font-semibold uppercase tracking-widest text-emerald-400">Live Cost Comparison</span>
        <h2 class="font-heading font-bold text-3xl sm:text-4xl text-white mt-2 mb-4">
          Calculate Your Production Savings
        </h2>
        <p class="text-slate-400 text-sm sm:text-base">
          Adjust the number of required editorial photos and video clips to see how much budget you save with Global Photoshoots.
        </p>
      </div>

      <div class="p-8 sm:p-10 rounded-3xl bg-[#0f131f] border border-white/10 shadow-2xl">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
          
          <!-- Controls Column -->
          <div class="space-y-6">
            
            <!-- Photos Range Slider -->
            <div>
              <div class="flex justify-between items-center mb-2">
                <label class="text-sm font-semibold text-white">Photos Needed:</label>
                <span id="photosCountDisplay" class="font-mono text-cyan-400 font-bold text-base">25 Photos</span>
              </div>
              <input 
                type="range" 
                id="photosRange" 
                min="5" 
                max="100" 
                value="25" 
                step="5" 
                class="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <div class="flex justify-between text-[11px] font-mono text-slate-400 mt-1">
                <span>5 photos</span>
                <span>50 photos</span>
                <span>100 photos</span>
              </div>
            </div>

            <!-- Videos Range Slider -->
            <div>
              <div class="flex justify-between items-center mb-2">
                <label class="text-sm font-semibold text-white">Cinematic AI Video Clips:</label>
                <span id="videosCountDisplay" class="font-mono text-indigo-400 font-bold text-base">4 Clips</span>
              </div>
              <input 
                type="range" 
                id="videosRange" 
                min="0" 
                max="20" 
                value="4" 
                step="1" 
                class="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <div class="flex justify-between text-[11px] font-mono text-slate-400 mt-1">
                <span>0 clips</span>
                <span>10 clips</span>
                <span>20 clips</span>
              </div>
            </div>

            <!-- Turnaround Speed Selector -->
            <div>
              <label class="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">Turnaround Speed:</label>
              <div class="grid grid-cols-2 gap-3">
                <button 
                  type="button" 
                  class="speed-toggle active py-2.5 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 bg-cyan-500/15 border-cyan-500/50 text-cyan-300 transition-all" 
                  data-speed="standard"
                >
                  <i data-lucide="clock" class="w-3.5 h-3.5"></i>
                  <span>Standard (48–72h)</span>
                </button>
                <button 
                  type="button" 
                  class="speed-toggle py-2.5 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 bg-white/5 border-white/10 text-slate-400 transition-all hover:border-white/20" 
                  data-speed="rush"
                >
                  <i data-lucide="zap" class="w-3.5 h-3.5"></i>
                  <span>Rush (24h Delivery)</span>
                </button>
              </div>
            </div>

          </div>

          <!-- Results Summary Card -->
          <div class="p-6 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col justify-between">
            <div class="space-y-4">
              <div class="text-xs font-mono uppercase tracking-wider text-slate-400">Campaign Estimate Breakdown</div>
              
              <div class="flex justify-between items-center text-sm">
                <span class="text-slate-400">Physical Shoot Estimated Cost:</span>
                <span id="traditionalCostDisplay" class="font-mono text-rose-400 line-through font-semibold">$13,800</span>
              </div>
              
              <div class="flex justify-between items-center text-base">
                <span class="flex items-center gap-1.5 font-medium text-white">
                  <i data-lucide="check-circle" class="w-4 h-4 text-cyan-400"></i>
                  Global Photoshoots AI:
                </span>
                <span id="aiCostDisplay" class="font-mono text-2xl text-cyan-300 font-extrabold">$840</span>
              </div>
              
              <div class="h-px bg-white/10 my-2"></div>
              
              <div class="flex justify-between items-center">
                <span class="font-bold text-white text-base">Your Net Savings:</span>
                <span id="netSavingsDisplay" class="font-mono text-2xl font-extrabold text-emerald-400">+$12,960</span>
              </div>
              
              <div class="flex justify-between items-center text-xs text-slate-400 font-mono">
                <span>Production Velocity:</span>
                <span id="daysSavedDisplay" class="text-indigo-300 font-bold">~21 Days Faster</span>
              </div>
            </div>

            <!-- Lock in Scope CTA -->
            <div class="mt-6 pt-4 border-t border-white/10">
              <a 
                href="#estimator-section" 
                class="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl text-sm font-bold bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white shadow-lg shadow-cyan-500/20 transition-all hover:scale-[1.02]"
              >
                <i data-lucide="send" class="w-4 h-4"></i>
                <span>Book This Scope with Sudhir</span>
              </a>
              <div class="mt-2 text-center">
                <a href="https://wa.me/917557575514" target="_blank" rel="noopener noreferrer" class="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center justify-center gap-1">
                  <i data-lucide="message-circle" class="w-3 h-3"></i>
                  <span>Or chat instantly on WhatsApp (+91 7557575514)</span>
                </a>
              </div>
            </div>

          </div>

        </div>
      </div>

    </div>
  </section>

  <!-- 8K COMMERCIAL PORTFOLIO -->
  <section id="portfolio" class="py-24 relative z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="flex flex-col md:flex-row md:items-end justify-between mb-12">
        <div>
          <span class="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">Featured Showcase</span>
          <h2 class="font-heading font-bold text-3xl sm:text-5xl text-white mt-2">
            8K Commercial Portfolio
          </h2>
          <p class="text-slate-400 text-sm sm:text-base mt-2 max-w-xl">
            Click any project to inspect full metadata, lighting schematics, and generation methodology.
          </p>
        </div>

        <!-- Filter Category Tabs -->
        <div class="mt-6 md:mt-0 flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          <button class="filter-btn active px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-500 text-black shadow-md shadow-cyan-500/30" data-filter="all">All Works</button>
          <button class="filter-btn px-4 py-2 rounded-xl text-xs font-semibold bg-white/5 text-slate-300 border border-white/5 hover:bg-white/10" data-filter="fashion">Fashion</button>
          <button class="filter-btn px-4 py-2 rounded-xl text-xs font-semibold bg-white/5 text-slate-300 border border-white/5 hover:bg-white/10" data-filter="product">Product &amp; Watches</button>
          <button class="filter-btn px-4 py-2 rounded-xl text-xs font-semibold bg-white/5 text-slate-300 border border-white/5 hover:bg-white/10" data-filter="beauty">Beauty &amp; Skincare</button>
          <button class="filter-btn px-4 py-2 rounded-xl text-xs font-semibold bg-white/5 text-slate-300 border border-white/5 hover:bg-white/10" data-filter="video">Cinematic Video</button>
        </div>
      </div>

      <!-- Portfolio Items Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="portfolioGrid">
        
        <!-- Item 1: Fashion -->
        <div class="portfolio-item group cursor-pointer" data-category="fashion" data-id="1">
          <div class="relative aspect-[4/5] rounded-2xl overflow-hidden bg-slate-900 border border-white/10 shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1600&auto=format&fit=crop" 
              alt="Neo-Couture Parisienne Spring Lookbook" 
              class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity"></div>
            
            <div class="absolute top-4 left-4">
              <span class="px-3 py-1 rounded-full text-[10px] font-mono font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 backdrop-blur-md">Fashion &amp; Editorial</span>
            </div>

            <div class="absolute bottom-4 left-4 right-4">
              <h4 class="font-heading font-bold text-lg text-white group-hover:text-cyan-300 transition-colors">Neo-Couture Parisienne Spring Lookbook</h4>
              <p class="text-xs text-slate-300 mt-1 line-clamp-2">Custom virtual models trained for luxury fashion brands with soft Parisian daylight.</p>
              <div class="mt-3 flex items-center justify-between text-[11px] font-mono text-cyan-400">
                <span>View Full Details &rarr;</span>
                <span>8K Master Render</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Item 2: Watches / Products -->
        <div class="portfolio-item group cursor-pointer" data-category="product" data-id="2">
          <div class="relative aspect-[4/5] rounded-2xl overflow-hidden bg-slate-900 border border-white/10 shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1600&auto=format&fit=crop" 
              alt="Obsidian Tourbillon Macro Campaign" 
              class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity"></div>
            
            <div class="absolute top-4 left-4">
              <span class="px-3 py-1 rounded-full text-[10px] font-mono font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 backdrop-blur-md">Luxury Watches &amp; Jewelry</span>
            </div>

            <div class="absolute bottom-4 left-4 right-4">
              <h4 class="font-heading font-bold text-lg text-white group-hover:text-cyan-300 transition-colors">Obsidian Tourbillon Macro Campaign</h4>
              <p class="text-xs text-slate-300 mt-1 line-clamp-2">Ray-traced sapphire crystal reflections and micro mechanical gears without dust or smudges.</p>
              <div class="mt-3 flex items-center justify-between text-[11px] font-mono text-cyan-400">
                <span>View Full Details &rarr;</span>
                <span>Macro 8K Shader</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Item 3: Beauty -->
        <div class="portfolio-item group cursor-pointer" data-category="beauty" data-id="3">
          <div class="relative aspect-[4/5] rounded-2xl overflow-hidden bg-slate-900 border border-white/10 shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=1600&auto=format&fit=crop" 
              alt="Botanical Dew Drops Skincare Series" 
              class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity"></div>
            
            <div class="absolute top-4 left-4">
              <span class="px-3 py-1 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 backdrop-blur-md">Cosmetics &amp; Beauty</span>
            </div>

            <div class="absolute bottom-4 left-4 right-4">
              <h4 class="font-heading font-bold text-lg text-white group-hover:text-cyan-300 transition-colors">Botanical Dew Drops Skincare Series</h4>
              <p class="text-xs text-slate-300 mt-1 line-clamp-2">Frosted glass translucency, real physical water surface tension, and organic morning sunlight.</p>
              <div class="mt-3 flex items-center justify-between text-[11px] font-mono text-cyan-400">
                <span>View Full Details &rarr;</span>
                <span>Subsurface Scattering</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Item 4: Video -->
        <div class="portfolio-item group cursor-pointer" data-category="video" data-id="4">
          <div class="relative aspect-[4/5] rounded-2xl overflow-hidden bg-slate-900 border border-white/10 shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=1600&auto=format&fit=crop" 
              alt="Electric Velocity: Brand Reel" 
              class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity"></div>
            
            <div class="absolute top-4 left-4">
              <span class="px-3 py-1 rounded-full text-[10px] font-mono font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/40 backdrop-blur-md">Cinematic AI Video</span>
            </div>

            <div class="absolute top-4 right-4 w-8 h-8 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shadow-lg">
              <i data-lucide="play" class="w-4 h-4 fill-current"></i>
            </div>

            <div class="absolute bottom-4 left-4 right-4">
              <h4 class="font-heading font-bold text-lg text-white group-hover:text-cyan-300 transition-colors">Electric Velocity: Brand Commercial Reel</h4>
              <p class="text-xs text-slate-300 mt-1 line-clamp-2">60 FPS seamless cinematic camera movement generated using combined diffusion &amp; motion vector models.</p>
              <div class="mt-3 flex items-center justify-between text-[11px] font-mono text-cyan-400">
                <span>View Full Details &rarr;</span>
                <span>4K 60FPS Video</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Item 5: Urban Streetwear Fashion -->
        <div class="portfolio-item group cursor-pointer" data-category="fashion" data-id="5">
          <div class="relative aspect-[4/5] rounded-2xl overflow-hidden bg-slate-900 border border-white/10 shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=1600&auto=format&fit=crop" 
              alt="Neo-Tokyo Techwear Capsule Lookbook" 
              class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity"></div>
            
            <div class="absolute top-4 left-4">
              <span class="px-3 py-1 rounded-full text-[10px] font-mono font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 backdrop-blur-md">Urban &amp; Streetwear</span>
            </div>

            <div class="absolute bottom-4 left-4 right-4">
              <h4 class="font-heading font-bold text-lg text-white group-hover:text-cyan-300 transition-colors">Neo-Tokyo Techwear Capsule Lookbook</h4>
              <p class="text-xs text-slate-300 mt-1 line-clamp-2">Atmospheric cyberpunk night aesthetics with wet pavement reflections and Gore-Tex textures.</p>
              <div class="mt-3 flex items-center justify-between text-[11px] font-mono text-cyan-400">
                <span>View Full Details &rarr;</span>
                <span>Atmospheric Volumetric</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Item 6: Portraits / Benchmarks -->
        <div class="portfolio-item group cursor-pointer" data-category="beauty" data-id="6">
          <div class="relative aspect-[4/5] rounded-2xl overflow-hidden bg-slate-900 border border-white/10 shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1600&auto=format&fit=crop" 
              alt="Skin Micro-Pores & Iris Depth Benchmark" 
              class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity"></div>
            
            <div class="absolute top-4 left-4">
              <span class="px-3 py-1 rounded-full text-[10px] font-mono font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/40 backdrop-blur-md">Hyper-Realistic Portraits</span>
            </div>

            <div class="absolute bottom-4 left-4 right-4">
              <h4 class="font-heading font-bold text-lg text-white group-hover:text-cyan-300 transition-colors">Skin Micro-Pores &amp; Iris Depth Benchmark</h4>
              <p class="text-xs text-slate-300 mt-1 line-clamp-2">Individual eyelash strands and natural eye catchlights without artificial plastic look.</p>
              <div class="mt-3 flex items-center justify-between text-[11px] font-mono text-cyan-400">
                <span>View Full Details &rarr;</span>
                <span>Photonic Eye Engine</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  </section>

  <!-- COMMERCIAL PACKAGES & PRICING -->
  <section id="packages" class="py-24 bg-[#0a0c14] border-y border-white/5 relative z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="text-center max-w-3xl mx-auto mb-16">
        <span class="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">Transparent Studio Tiers</span>
        <h2 class="font-heading font-bold text-3xl sm:text-5xl text-white mt-2 mb-4">
          Commercial Production Packages
        </h2>
        <p class="text-slate-400 text-sm sm:text-base">
          All packages include full commercial buyout rights, infinite revision support, and high-fidelity upscaling.
        </p>
      </div>

      <!-- Pricing Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch">
        
        <!-- Tier 1: Starter -->
        <div class="p-8 rounded-3xl bg-[#0f131f] border border-white/10 flex flex-col justify-between hover:border-cyan-500/30 transition-all">
          <div>
            <div class="flex justify-between items-center mb-4">
              <span class="text-xs font-mono text-cyan-400 font-semibold uppercase">Starter Campaign</span>
              <span class="px-2.5 py-0.5 rounded-full bg-white/5 text-slate-400 text-[11px]">E-Commerce</span>
            </div>
            
            <h3 class="font-heading font-bold text-2xl text-white mb-2">Lookbook Essential</h3>
            <p class="text-xs text-slate-400 mb-6">Ideal for Amazon, Shopify stores, and indie fashion launches.</p>
            
            <div class="flex items-baseline gap-1 mb-6">
              <span class="text-4xl font-extrabold text-white font-mono" data-usd-price="249">$249</span>
              <span class="text-xs text-slate-400">/ project</span>
            </div>

            <div class="h-px bg-white/10 mb-6"></div>

            <ul class="space-y-3.5 text-xs text-slate-300">
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span><strong>10 High-Res 8K Renders</strong></span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>1 Virtual Model Persona (Tailored Look)</span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>2 Custom Studio Lighting Setups</span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>48-Hour Delivery Handover</span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>100% Commercial Buyout License</span>
              </li>
            </ul>
          </div>

          <div class="mt-8 pt-6 border-t border-white/10">
            <a 
              href="https://wa.me/917557575514?text=Hi%20Sudhir!%20I%20want%20to%20book%20the%20Starter%20Lookbook%20Package%20($249)." 
              target="_blank" 
              rel="noopener noreferrer" 
              class="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-all"
            >
              <i data-lucide="message-circle" class="w-4 h-4 text-emerald-400"></i>
              <span>Book Starter via WhatsApp</span>
            </a>
          </div>
        </div>

        <!-- Tier 2: Commercial Brand (Featured) -->
        <div class="p-8 rounded-3xl bg-gradient-to-b from-[#141b2d] to-[#0f131f] border-2 border-cyan-400 flex flex-col justify-between relative shadow-2xl shadow-cyan-500/20 transform md:-translate-y-2">
          <div class="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-cyan-400 text-slate-950 text-xs font-heading font-extrabold uppercase tracking-wider shadow-lg">
            Most Popular
          </div>

          <div>
            <div class="flex justify-between items-center mb-4 mt-2">
              <span class="text-xs font-mono text-cyan-300 font-semibold uppercase">Brand Growth</span>
              <span class="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[11px] font-semibold">Photo + Video</span>
            </div>
            
            <h3 class="font-heading font-bold text-2xl text-white mb-2">Commercial Brand</h3>
            <p class="text-xs text-slate-300 mb-6">Designed for scale-ups, advertising agencies, and social campaigns.</p>
            
            <div class="flex items-baseline gap-1 mb-6">
              <span class="text-4xl font-extrabold text-white font-mono" data-usd-price="599">$599</span>
              <span class="text-xs text-slate-400">/ project</span>
            </div>

            <div class="h-px bg-white/10 mb-6"></div>

            <ul class="space-y-3.5 text-xs text-slate-200">
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span><strong>25 High-Res 8K Editorial Renders</strong></span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span><strong>2 Cinematic AI Video Clips (4K 60FPS)</strong></span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>3 Diverse Virtual Models</span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>Multi-Angle Studio &amp; Exotic Outdoor Scenes</span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>Priority 24&ndash;48h Handover + Revisions</span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>Full Commercial Broadcast Rights</span>
              </li>
            </ul>
          </div>

          <div class="mt-8 pt-6 border-t border-white/10">
            <a 
              href="https://wa.me/917557575514?text=Hi%20Sudhir!%20I%20want%20to%20commission%20the%20Commercial%20Brand%20Package%20($599)." 
              target="_blank" 
              rel="noopener noreferrer" 
              class="w-full inline-flex items-center justify-center gap-2 py-3.5 rounded-xl text-xs font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 transition-all shadow-lg shadow-cyan-400/30"
            >
              <i data-lucide="message-circle" class="w-4 h-4"></i>
              <span>Book Commercial Brand Tier</span>
            </a>
          </div>
        </div>

        <!-- Tier 3: Enterprise / Custom Studio -->
        <div class="p-8 rounded-3xl bg-[#0f131f] border border-white/10 flex flex-col justify-between hover:border-indigo-500/30 transition-all">
          <div>
            <div class="flex justify-between items-center mb-4">
              <span class="text-xs font-mono text-indigo-400 font-semibold uppercase">Enterprise Retainer</span>
              <span class="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px]">Full Scale</span>
            </div>
            
            <h3 class="font-heading font-bold text-2xl text-white mb-2">Omnichannel Campaign</h3>
            <p class="text-xs text-slate-400 mb-6">Complete visual catalogue for global brands and multi-product catalogues.</p>
            
            <div class="flex items-baseline gap-1 mb-6">
              <span class="text-4xl font-extrabold text-white font-mono" data-usd-price="1299">$1,299</span>
              <span class="text-xs text-slate-400">/ project</span>
            </div>

            <div class="h-px bg-white/10 mb-6"></div>

            <ul class="space-y-3.5 text-xs text-slate-300">
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span><strong>60 High-Res 8K Master Renders</strong></span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span><strong>6 Cinematic AI Video Reels (Instagram / TikTok)</strong></span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span><strong>Custom LoRA Trained on Your Physical Product</strong></span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>Unlimited Environments &amp; Wardrobe Changes</span>
              </li>
              <li class="flex items-center gap-2.5">
                <i data-lucide="check" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                <span>Dedicated Creative Direction by Sudhir</span>
              </li>
            </ul>
          </div>

          <div class="mt-8 pt-6 border-t border-white/10">
            <a 
              href="https://wa.me/917557575514?text=Hi%20Sudhir!%20I%20am%20interested%20in%20the%20Omnichannel%20Enterprise%20Package%20($1,299)." 
              target="_blank" 
              rel="noopener noreferrer" 
              class="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-all"
            >
              <i data-lucide="message-circle" class="w-4 h-4 text-emerald-400"></i>
              <span>Book Enterprise via WhatsApp</span>
            </a>
          </div>
        </div>

      </div>

    </div>
  </section>

  <!-- DIGITAL PRODUCTS & PROMPTS STORE -->
  <section id="store" class="py-24 relative z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="flex flex-col md:flex-row md:items-end justify-between mb-12">
        <div>
          <span class="text-xs font-mono font-semibold uppercase tracking-widest text-emerald-400">Creator &amp; Agency Tooling</span>
          <h2 class="font-heading font-bold text-3xl sm:text-5xl text-white mt-2">
            Digital Products &amp; Prompt Vault
          </h2>
          <p class="text-slate-400 text-sm sm:text-base mt-2 max-w-xl">
            Plug-and-play professional AI photography assets, lighting formulas, and model LoRA weights crafted by Sudhir Kumar Solanki.
          </p>
        </div>

        <div class="mt-4 md:mt-0 flex items-center gap-2 text-xs font-mono text-slate-400">
          <i data-lucide="download" class="w-4 h-4 text-emerald-400"></i>
          <span>Instant Download &bull; Commercial License</span>
        </div>
      </div>

      <!-- Products Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        <!-- Product 1 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/10 hover:border-emerald-500/40 transition-all flex flex-col justify-between group">
          <div>
            <div class="w-12 h-12 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <i data-lucide="file-code-2" class="w-6 h-6"></i>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 uppercase tracking-wider font-semibold">Prompt Library</span>
            <h4 class="font-heading font-bold text-lg text-white mt-1 mb-2">Master Studio Lighting Prompt Vault</h4>
            <p class="text-xs text-slate-400 line-clamp-3">Over 150+ battle-tested Midjourney v6 &amp; Flux prompt templates replicating Profoto strobe physics, butterfly lighting, and rim flares.</p>
          </div>

          <div class="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
            <div>
              <span class="text-xs text-slate-400 block font-mono">Price</span>
              <span class="font-mono text-lg font-bold text-white" data-usd-price="29">$29</span>
            </div>
            <button 
              class="digital-product-btn px-3 py-2 rounded-xl text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors"
              data-product="Master Studio Lighting Prompt Vault"
              data-usd-price="29"
            >
              Get Vault
            </button>
          </div>
        </div>

        <!-- Product 2 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/10 hover:border-cyan-500/40 transition-all flex flex-col justify-between group">
          <div>
            <div class="w-12 h-12 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <i data-lucide="layers" class="w-6 h-6"></i>
            </div>
            <span class="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-semibold">LoRA Weights</span>
            <h4 class="font-heading font-bold text-lg text-white mt-1 mb-2">High-End Editorial Fashion LoRA</h4>
            <p class="text-xs text-slate-400 line-clamp-3">Precision trained model weights for Flux.1 and SDXL that enforce realistic silk drape physics, haute couture tailoring, and luxury poses.</p>
          </div>

          <div class="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
            <div>
              <span class="text-xs text-slate-400 block font-mono">Price</span>
              <span class="font-mono text-lg font-bold text-white" data-usd-price="49">$49</span>
            </div>
            <button 
              class="digital-product-btn px-3 py-2 rounded-xl text-xs font-semibold bg-cyan-400 hover:bg-cyan-300 text-slate-950 transition-colors"
              data-product="High-End Editorial Fashion LoRA Weights"
              data-usd-price="49"
            >
              Get LoRA
            </button>
          </div>
        </div>

        <!-- Product 3 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/10 hover:border-indigo-500/40 transition-all flex flex-col justify-between group">
          <div>
            <div class="w-12 h-12 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <i data-lucide="video" class="w-6 h-6"></i>
            </div>
            <span class="text-[10px] font-mono text-indigo-400 uppercase tracking-wider font-semibold">Video Workflows</span>
            <h4 class="font-heading font-bold text-lg text-white mt-1 mb-2">Cinematic AI Video Motion Presets</h4>
            <p class="text-xs text-slate-400 line-clamp-3">ComfyUI &amp; Runway Gen-3 workflows for stable 60 FPS camera pans, macro zooms, and smooth slow-motion commercial b-roll.</p>
          </div>

          <div class="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
            <div>
              <span class="text-xs text-slate-400 block font-mono">Price</span>
              <span class="font-mono text-lg font-bold text-white" data-usd-price="39">$39</span>
            </div>
            <button 
              class="digital-product-btn px-3 py-2 rounded-xl text-xs font-semibold bg-indigo-400 hover:bg-indigo-300 text-slate-950 transition-colors"
              data-product="Cinematic AI Video Motion Presets"
              data-usd-price="39"
            >
              Get Presets
            </button>
          </div>
        </div>

        <!-- Product 4 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/10 hover:border-amber-500/40 transition-all flex flex-col justify-between group">
          <div>
            <div class="w-12 h-12 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <i data-lucide="sparkles" class="w-6 h-6"></i>
            </div>
            <span class="text-[10px] font-mono text-amber-400 uppercase tracking-wider font-semibold">Jewelry Shaders</span>
            <h4 class="font-heading font-bold text-lg text-white mt-1 mb-2">Macro Jewelry &amp; Reflection Kit</h4>
            <p class="text-xs text-slate-400 line-clamp-3">Master formulas for ray-traced gemstone refraction, gold brushed specular highlights, and zero-distortion diamond caustics.</p>
          </div>

          <div class="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
            <div>
              <span class="text-xs text-slate-400 block font-mono">Price</span>
              <span class="font-mono text-lg font-bold text-white" data-usd-price="35">$35</span>
            </div>
            <button 
              class="digital-product-btn px-3 py-2 rounded-xl text-xs font-semibold bg-amber-400 hover:bg-amber-300 text-slate-950 transition-colors"
              data-product="Macro Jewelry &amp; Reflection Masterclass"
              data-usd-price="35"
            >
              Get Kit
            </button>
          </div>
        </div>

      </div>

    </div>
  </section>

  <!-- 4-STEP PRODUCTION WORKFLOW -->
  <section id="workflow" class="py-24 bg-[#0a0c14] border-y border-white/5 relative z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="text-center max-w-3xl mx-auto mb-16">
        <span class="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">Effortless Delivery</span>
        <h2 class="font-heading font-bold text-3xl sm:text-5xl text-white mt-2 mb-4">
          How A Global Photoshoots Production Works
        </h2>
        <p class="text-slate-400 text-sm sm:text-base">
          From your initial brief to billboard-ready 8K master files in 4 streamlined steps.
        </p>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        
        <!-- Step 1 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/5 relative">
          <div class="font-mono text-3xl font-extrabold text-cyan-400/40 mb-3">01</div>
          <h3 class="font-heading font-bold text-lg text-white mb-2">Brand Vision &amp; Asset Intake</h3>
          <p class="text-xs text-slate-400 leading-relaxed">
            You share your moodboard, product photos, or aesthetic references with Sudhir on WhatsApp or Instagram.
          </p>
        </div>

        <!-- Step 2 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/5 relative">
          <div class="font-mono text-3xl font-extrabold text-indigo-400/40 mb-3">02</div>
          <h3 class="font-heading font-bold text-lg text-white mb-2">Model &amp; Scene Synthesis</h3>
          <p class="text-xs text-slate-400 leading-relaxed">
            We generate custom virtual models matching your exact demographics and place them in photorealistic environments.
          </p>
        </div>

        <!-- Step 3 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/5 relative">
          <div class="font-mono text-3xl font-extrabold text-purple-400/40 mb-3">03</div>
          <h3 class="font-heading font-bold text-lg text-white mb-2">Lighting &amp; 8K Upscaling</h3>
          <p class="text-xs text-slate-400 leading-relaxed">
            We apply raytraced optical physics, micro-skin textures, and upscale outputs to native 8192px print resolution.
          </p>
        </div>

        <!-- Step 4 -->
        <div class="p-6 rounded-2xl bg-[#0f131f] border border-white/5 relative">
          <div class="font-mono text-3xl font-extrabold text-emerald-400/40 mb-3">04</div>
          <h3 class="font-heading font-bold text-lg text-white mb-2">Commercial Handover</h3>
          <p class="text-xs text-slate-400 leading-relaxed">
            Download your high-resolution image and 4K video files via high-speed cloud drive with 100% full commercial IP rights.
          </p>
        </div>

      </div>

    </div>
  </section>

  <!-- DUAL INQUIRY ESTIMATOR & BOOKING FORM -->
  <section id="estimator-section" class="py-24 relative z-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="text-center max-w-2xl mx-auto mb-12">
        <span class="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">Direct Commission</span>
        <h2 class="font-heading font-bold text-3xl sm:text-5xl text-white mt-2 mb-4">
          Book Your AI Photoshoot
        </h2>
        <p class="text-slate-400 text-sm">
          Fill out your project requirements below. You can send the formatted brief directly to Sudhir on Instagram DM or WhatsApp.
        </p>
      </div>

      <!-- Success Toast Alert -->
      <div id="formSuccessToast" class="hidden mb-6 p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs sm:text-sm flex items-center justify-between shadow-lg">
        <div class="flex items-center gap-2.5">
          <i data-lucide="check-circle-2" class="w-5 h-5 text-emerald-400 shrink-0"></i>
          <span><strong>Brief Copied to Clipboard!</strong> Directing you to chat with Sudhir now...</span>
        </div>
      </div>

      <!-- Form Container -->
      <form id="shootInquiryForm" class="p-8 sm:p-10 rounded-3xl bg-[#0f131f] border border-white/10 shadow-2xl space-y-6">
        
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label for="clientName" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Your Name or Brand</label>
            <input 
              type="text" 
              id="clientName" 
              placeholder="e.g. Acme Apparel / Sarah Jenkins" 
              class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
              required 
            />
          </div>

          <div>
            <label for="clientContact" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">WhatsApp or Instagram Handle</label>
            <input 
              type="text" 
              id="clientContact" 
              placeholder="e.g. +1 555-0199 or @brandhandle" 
              class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
              required 
            />
          </div>
        </div>

        <!-- Scope / Project Type Radios -->
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Production Type</label>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <label class="flex items-center gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-500/50 cursor-pointer">
              <input type="radio" name="projectType" value="AI Photoshoot Campaign" checked class="text-cyan-400 focus:ring-0" />
              <span class="text-xs font-medium text-white">AI Photoshoot</span>
            </label>
            <label class="flex items-center gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-500/50 cursor-pointer">
              <input type="radio" name="projectType" value="Cinematic AI Video Reels" class="text-cyan-400 focus:ring-0" />
              <span class="text-xs font-medium text-white">Cinematic Video</span>
            </label>
            <label class="flex items-center gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-500/50 cursor-pointer">
              <input type="radio" name="projectType" value="Custom LoRA & Digital Assets" class="text-cyan-400 focus:ring-0" />
              <span class="text-xs font-medium text-white">Custom Model / LoRA</span>
            </label>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label for="deliverableCount" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Estimated Deliverables</label>
            <select id="deliverableCount" class="w-full bg-[#0a0d16] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-400">
              <option value="10-15 Photos (Lookbook Starter)">10–15 Photos (Lookbook Starter)</option>
              <option value="25 Photos + 2 AI Video Clips (Commercial Brand)" selected>25 Photos + 2 AI Video Clips (Commercial Brand)</option>
              <option value="50+ Photos + 5 Video Clips (Omnichannel)">50+ Photos + 5 Video Clips (Omnichannel)</option>
              <option value="Custom Enterprise / Multi-Product">Custom Enterprise / Multi-Product</option>
            </select>
          </div>

          <div>
            <label for="turnaroundPreference" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Required Timeline</label>
            <select id="turnaroundPreference" class="w-full bg-[#0a0d16] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-400">
              <option value="Within 24 Hours (Rush Delivery)">Within 24 Hours (Rush Delivery)</option>
              <option value="48-72 Hours (Standard Production)" selected>48–72 Hours (Standard Production)</option>
              <option value="Flexible / Planning for Next Month">Flexible / Planning for Next Month</option>
            </select>
          </div>
        </div>

        <div>
          <label for="projectDetails" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Describe Your Creative Vision</label>
          <textarea 
            id="projectDetails" 
            rows="3" 
            placeholder="Tell us about the aesthetic, preferred models, lighting style, or product reference..." 
            class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
          ></textarea>
        </div>

        <!-- Dispatch Buttons -->
        <div class="pt-4 flex flex-col sm:flex-row gap-4">
          <button 
            type="button" 
            id="sendToWhatsAppBtn" 
            class="flex-1 inline-flex items-center justify-center gap-2.5 py-4 px-6 rounded-xl font-bold text-sm bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all shadow-lg shadow-emerald-500/25"
          >
            <i data-lucide="message-circle" class="w-5 h-5"></i>
            <span>Send Brief on WhatsApp (+91 7557575514)</span>
          </button>

          <button 
            type="button" 
            id="sendToInstagramBtn" 
            class="flex-1 inline-flex items-center justify-center gap-2.5 py-4 px-6 rounded-xl font-bold text-sm bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:brightness-110 text-white transition-all shadow-lg shadow-pink-600/25"
          >
            <i data-lucide="instagram" class="w-5 h-5"></i>
            <span>Send Brief on Instagram (@global.photoshoots)</span>
          </button>
        </div>

      </form>

    </div>
  </section>

  <!-- FAQS ACCORDION -->
  <section id="faq" class="py-24 bg-[#0a0c14] border-y border-white/5 relative z-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div class="text-center max-w-2xl mx-auto mb-16">
        <span class="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">Questions &amp; Answers</span>
        <h2 class="font-heading font-bold text-3xl sm:text-5xl text-white mt-2 mb-4">
          Frequently Asked Questions
        </h2>
        <p class="text-slate-400 text-sm">
          Everything you need to know about working with Global Photoshoots.
        </p>
      </div>

      <div class="space-y-4">
        
        <!-- FAQ 1 -->
        <div class="faq-item p-6 rounded-2xl bg-[#0f131f] border border-white/5 cursor-pointer hover:border-white/15 transition-all">
          <div class="flex items-center justify-between">
            <h3 class="font-semibold text-base text-white">Can AI photoshoots accurately replicate my exact physical product?</h3>
            <i data-lucide="chevron-down" class="w-5 h-5 text-cyan-400 transition-transform duration-300"></i>
          </div>
          <div class="faq-answer hidden mt-3 text-sm text-slate-300 leading-relaxed border-t border-white/5 pt-3">
            Yes! For custom garments, watches, or beauty packaging, we train lightweight LoRA adapter models directly on photos of your physical product. This guarantees 100% preservation of logos, fabric weave, seam stitching, and labels without hallucinated flaws.
          </div>
        </div>

        <!-- FAQ 2 -->
        <div class="faq-item p-6 rounded-2xl bg-[#0f131f] border border-white/5 cursor-pointer hover:border-white/15 transition-all">
          <div class="flex items-center justify-between">
            <h3 class="font-semibold text-base text-white">Do I get full commercial copyright ownership?</h3>
            <i data-lucide="chevron-down" class="w-5 h-5 text-cyan-400 transition-transform duration-300"></i>
          </div>
          <div class="faq-answer hidden mt-3 text-sm text-slate-300 leading-relaxed border-t border-white/5 pt-3">
            Absolutely. Every delivered image and video comes with a worldwide, perpetual commercial usage buyout. You are free to publish them on billboards, TV commercials, Amazon product listings, social ads, and print lookbooks with zero recurring model royalties.
          </div>
        </div>

        <!-- FAQ 3 -->
        <div class="faq-item p-6 rounded-2xl bg-[#0f131f] border border-white/5 cursor-pointer hover:border-white/15 transition-all">
          <div class="flex items-center justify-between">
            <h3 class="font-semibold text-base text-white">How fast will I receive my campaign files?</h3>
            <i data-lucide="chevron-down" class="w-5 h-5 text-cyan-400 transition-transform duration-300"></i>
          </div>
          <div class="faq-answer hidden mt-3 text-sm text-slate-300 leading-relaxed border-t border-white/5 pt-3">
            Standard campaign deliveries are completed within 48 to 72 hours. If you have an urgent product launch or flash sale, our Rush Delivery option can deliver production-ready 8K master renders within 24 hours.
          </div>
        </div>

        <!-- FAQ 4 -->
        <div class="faq-item p-6 rounded-2xl bg-[#0f131f] border border-white/5 cursor-pointer hover:border-white/15 transition-all">
          <div class="flex items-center justify-between">
            <h3 class="font-semibold text-base text-white">Can you generate cinematic AI video reels for Instagram &amp; TikTok?</h3>
            <i data-lucide="chevron-down" class="w-5 h-5 text-cyan-400 transition-transform duration-300"></i>
          </div>
          <div class="faq-answer hidden mt-3 text-sm text-slate-300 leading-relaxed border-t border-white/5 pt-3">
            Yes! We specialize in 4K 60FPS cinematic AI video reels, camera dollies, slow-motion fabric flows, and model runway clips. These are optimized for 9:16 vertical reels and standard 16:9 widescreen commercial displays.
          </div>
        </div>

        <!-- FAQ 5 -->
        <div class="faq-item p-6 rounded-2xl bg-[#0f131f] border border-white/5 cursor-pointer hover:border-white/15 transition-all">
          <div class="flex items-center justify-between">
            <h3 class="font-semibold text-base text-white">How do we initiate a project and handle payments?</h3>
            <i data-lucide="chevron-down" class="w-5 h-5 text-cyan-400 transition-transform duration-300"></i>
          </div>
          <div class="faq-answer hidden mt-3 text-sm text-slate-300 leading-relaxed border-t border-white/5 pt-3">
            Simply click any WhatsApp or Instagram DM button to message Sudhir directly. We review your scope, provide sample preview renders, and invoice via Stripe, Wise, UPI, or PayPal with milestone payments.
          </div>
        </div>

      </div>

    </div>
  </section>

  <!-- FOOTER -->
  <footer class="bg-[#05070a] border-t border-white/10 py-16 relative z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 md:grid-cols-4 gap-10">
        
        <!-- Col 1: Brand -->
        <div class="md:col-span-2">
          <a href="#" class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 p-[2px]">
              <div class="w-full h-full bg-[#0a0d16] rounded-[10px] flex items-center justify-center">
                <i data-lucide="aperture" class="w-5 h-5 text-cyan-400"></i>
              </div>
            </div>
            <div>
              <span class="font-heading font-extrabold text-lg text-white">GLOBAL<span class="text-cyan-400">PHOTOSHOOTS</span></span>
              <p class="text-[11px] font-mono text-slate-400">Founded by Sudhir Kumar Solanki</p>
            </div>
          </a>
          <p class="text-xs text-slate-400 mt-4 max-w-sm leading-relaxed">
            Leading the revolution in generative physics, luxury AI editorial photography, and commercial video production. Delivering high-fashion fidelity at 90% lower cost.
          </p>
          <div class="mt-4 flex items-center gap-3">
            <a href="https://www.instagram.com/global.photoshoots/#" target="_blank" rel="noopener noreferrer" class="p-2.5 rounded-xl bg-white/5 hover:bg-pink-600/20 text-slate-400 hover:text-pink-400 border border-white/5 transition-colors">
              <i data-lucide="instagram" class="w-4 h-4"></i>
            </a>
            <a href="https://wa.me/917557575514" target="_blank" rel="noopener noreferrer" class="p-2.5 rounded-xl bg-white/5 hover:bg-emerald-600/20 text-slate-400 hover:text-emerald-400 border border-white/5 transition-colors">
              <i data-lucide="message-circle" class="w-4 h-4"></i>
            </a>
            <a href="mailto:sudhir@globalphotoshoots.com" class="p-2.5 rounded-xl bg-white/5 hover:bg-cyan-600/20 text-slate-400 hover:text-cyan-400 border border-white/5 transition-colors">
              <i data-lucide="mail" class="w-4 h-4"></i>
            </a>
          </div>
        </div>

        <!-- Col 2: Navigation -->
        <div>
          <h4 class="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4">Studio Navigation</h4>
          <ul class="space-y-2.5 text-xs text-slate-400">
            <li><a href="#showcase" class="hover:text-cyan-400 transition-colors">Generative Physics Demo</a></li>
            <li><a href="#why-ai" class="hover:text-cyan-400 transition-colors">Why AI Over Physical</a></li>
            <li><a href="#calculator" class="hover:text-cyan-400 transition-colors">Production Cost Calculator</a></li>
            <li><a href="#portfolio" class="hover:text-cyan-400 transition-colors">8K Master Portfolio</a></li>
            <li><a href="#packages" class="hover:text-cyan-400 transition-colors">Commercial Pricing Tiers</a></li>
          </ul>
        </div>

        <!-- Col 3: Direct Connect -->
        <div>
          <h4 class="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4">Direct Contact</h4>
          <ul class="space-y-2.5 text-xs text-slate-400">
            <li>
              <a href="https://www.instagram.com/global.photoshoots/#" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 hover:text-pink-400 transition-colors">
                <i data-lucide="instagram" class="w-3.5 h-3.5 text-pink-400"></i>
                <span>@global.photoshoots</span>
              </a>
            </li>
            <li>
              <a href="https://wa.me/917557575514" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 hover:text-emerald-400 transition-colors">
                <i data-lucide="message-circle" class="w-3.5 h-3.5 text-emerald-400"></i>
                <span>WhatsApp: +91 7557575514</span>
              </a>
            </li>
            <li>
              <span class="text-slate-400">Lead Art Director: Sudhir Kumar Solanki</span>
            </li>
            <li class="pt-2">
              <span class="inline-block px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-mono border border-emerald-500/20">
                &bull; Status: Available for New Campaigns
              </span>
            </li>
          </ul>
        </div>

      </div>

      <div class="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 font-mono">
        <p>&copy; <span id="currentYear">2026</span> Global Photoshoots by Sudhir Kumar Solanki. All rights reserved.</p>
        <p class="mt-2 sm:mt-0">Crafted for Global Commercial AI Excellence</p>
      </div>
    </div>
  </footer>

  <!-- FLOATING QUICK ACTION DOCK -->
  <div class="floating-dock">
    <!-- WhatsApp Floating Pulse Button -->
    <a 
      href="https://wa.me/917557575514?text=Hi%20Sudhir!%20I%20am%20interested%20in%20an%20AI%20Photoshoot%20for%20my%20brand." 
      target="_blank" 
      rel="noopener noreferrer" 
      class="whatsapp-pulse w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shadow-2xl transition-all transform hover:scale-110 group"
      title="Direct WhatsApp with Sudhir"
    >
      <i data-lucide="message-circle" class="w-7 h-7 fill-current"></i>
      <span class="sr-only">Chat on WhatsApp</span>
    </a>

    <!-- Instagram Floating Button -->
    <a 
      href="https://www.instagram.com/global.photoshoots/#" 
      target="_blank" 
      rel="noopener noreferrer" 
      class="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 via-rose-600 to-purple-600 hover:brightness-110 text-white flex items-center justify-center shadow-2xl transition-all transform hover:scale-110"
      title="Visit @global.photoshoots on Instagram"
    >
      <i data-lucide="instagram" class="w-7 h-7"></i>
      <span class="sr-only">Visit Instagram Profile</span>
    </a>
  </div>

  <!-- PORTFOLIO LIGHTBOX MODAL -->
  <div id="lightboxModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6">
    <div class="relative max-w-4xl w-full bg-[#0f131f] border border-white/15 rounded-3xl overflow-hidden shadow-2xl">
      <button id="closeLightboxBtn" class="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-white/20 transition-colors">
        <i data-lucide="x" class="w-5 h-5"></i>
      </button>

      <div class="grid grid-cols-1 md:grid-cols-2">
        <div class="aspect-square bg-black">
          <img id="lightboxImg" src="" alt="Showcase Preview" class="w-full h-full object-cover" />
        </div>
        <div class="p-8 flex flex-col justify-between">
          <div>
            <span id="lightboxCategory" class="px-3 py-1 rounded-full text-[10px] font-mono font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">Category</span>
            <h3 id="lightboxTitle" class="font-heading font-bold text-2xl text-white mt-3 mb-4">Project Title</h3>
            <p id="lightboxDescription" class="text-xs sm:text-sm text-slate-300 leading-relaxed">Detailed breakdown of generative methodology and lighting schematics.</p>
          </div>

          <div class="mt-8 pt-6 border-t border-white/10 space-y-3">
            <a 
              href="#estimator-section" 
              onclick="document.getElementById('lightboxModal').classList.add('hidden')"
              class="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 transition-colors"
            >
              <span>Commission Similar Campaign</span>
              <i data-lucide="arrow-right" class="w-4 h-4"></i>
            </a>
            <a 
              href="https://www.instagram.com/global.photoshoots/#" 
              target="_blank" 
              rel="noopener noreferrer" 
              class="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-colors"
            >
              <i data-lucide="instagram" class="w-4 h-4 text-pink-400"></i>
              <span>View More on Instagram</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- DIGITAL PRODUCT PURCHASE MODAL -->
  <div id="productModal" class="hidden fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4">
    <div class="relative max-w-md w-full bg-[#0f131f] border border-white/15 rounded-3xl p-8 shadow-2xl">
      <button id="closeModalBtn" class="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors">
        <i data-lucide="x" class="w-4 h-4"></i>
      </button>

      <div class="text-center">
        <div class="w-14 h-14 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto mb-4">
          <i data-lucide="package-check" class="w-7 h-7"></i>
        </div>
        <span class="text-[10px] font-mono text-cyan-400 uppercase tracking-widest font-semibold">Instant Digital Access</span>
        <h3 id="modalProductTitle" class="font-heading font-bold text-xl text-white mt-1 mb-2">Digital Asset</h3>
        <div id="modalProductPrice" class="font-mono text-3xl font-extrabold text-cyan-300 my-4">$29</div>
        <p class="text-xs text-slate-400 mb-6">
          Includes comprehensive PDF documentation, raw prompt text configurations, sample visual guides, and commercial license key.
        </p>

        <div class="space-y-3">
          <button 
            id="modalWhatsAppBtn" 
            class="w-full inline-flex items-center justify-center gap-2 py-3.5 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow-lg shadow-emerald-500/20"
          >
            <i data-lucide="message-circle" class="w-4 h-4"></i>
            <span>Instant Purchase via WhatsApp</span>
          </button>

          <button 
            id="modalSimulatePayBtn" 
            class="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-colors"
          >
            <i data-lucide="credit-card" class="w-4 h-4"></i>
            <span>Checkout with Card / PayPal</span>
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Studio Config & Application Scripts -->
  <script src="config.js"></script>
  <script src="app.js"></script>
</body>
</html>
"""

def main():
    target_path = os.path.join(os.path.dirname(__file__), "index.html")
    with open(target_path, "w", encoding="utf-8") as f:
        f.write(HTML_CONTENT.strip())
    print(f"Successfully generated {target_path} ({len(HTML_CONTENT)} characters)")

if __name__ == "__main__":
    main()
